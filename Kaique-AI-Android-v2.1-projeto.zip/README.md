# Kaique AI v2.1 — Android

Baseado no projeto v2.0. Inclui interface Android (Capacitor), backend Node.js, exportação de conversa em TXT, rascunho salvo localmente, teste de conexão com backend, recuperação da última mensagem para reenvio, timeout no servidor e modelo de imagem configurável.

## Como gerar APK pelo celular

1. Extraia este ZIP pelo app Arquivos do Android.
2. Crie um repositório privado em https://github.com/new.
3. Envie **todos os arquivos e pastas** preservando `.github/workflows/android-apk.yml`. O navegador pode não enviar pastas inteiras; use um cliente Git Android ou GitHub Codespaces se necessário.
4. Abra **Actions → Gerar APK Kaique AI → Run workflow**. Se Actions estiver desabilitado, habilite na configuração do repositório.
5. Ao concluir, baixe o artefato `Kaique-AI-debug-APK`, extraia e instale `app-debug.apk`.

## Servidor da IA

Hospede `backend/` em serviço Node.js 20+ com HTTPS. Configure `OPENAI_API_KEY`, opcionalmente `OPENAI_MODEL`, `OPENAI_IMAGE_MODEL` e `APP_ACCESS_TOKEN`. Rode `npm install` e `npm start`. Informe a URL HTTPS em Configurações do app. Nunca coloque a chave OpenAI no APK nem no GitHub. **O token simples não é autenticação adequada para produção.**

## Estado e limitações

- Código de interface e servidor com sintaxe verificada, **não compilado/testado em dispositivo Android**.
- Chat e imagem dependem de provedor e backend configurados, com cobrança/cotas possíveis.
- Voz ainda usa recursos do WebView; pode não funcionar em todos os aparelhos.
- Pesquisa web profunda, voz neural premium e vídeo não estão implementados.
- Exportação via download pode depender do suporte do WebView; se não funcionar, será necessário plugin nativo de compartilhamento.
- A interface carrega offline; IA precisa de internet.
- A compilação cria um APK debug, não um pacote pronto para Play Store.
