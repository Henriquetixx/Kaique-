import express from 'express';
import dotenv from 'dotenv';
dotenv.config();
const app=express();app.use((req,res,next)=>{const origin=req.headers.origin;if(origin==='https://localhost'||origin==='http://localhost'){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');}if(req.method==='OPTIONS')return res.sendStatus(204);next()});app.use(express.json({limit:'1mb'}));app.use(express.static('public'));
const calls=new Map();app.get('/health',(req,res)=>res.json({ok:true,app:'Kaique AI',version:'2.1'}));app.use('/api',(req,res,next)=>{const expected=process.env.APP_ACCESS_TOKEN;if(expected&&req.headers.authorization!==`Bearer ${expected}`)return res.status(401).json({error:'Token de acesso inválido.'});const key=req.ip||'unknown',now=Date.now();const hit=calls.get(key)||{start:now,count:0};if(now-hit.start>60000){hit.start=now;hit.count=0}hit.count++;calls.set(key,hit);if(hit.count>15)return res.status(429).json({error:'Limite temporário de solicitações.'});next()});setInterval(()=>{const now=Date.now();for(const [key,v] of calls)if(now-v.start>120000)calls.delete(key)},120000).unref();app.post('/api/chat',async(req,res)=>{
 const {messages}=req.body||{};
 if(!Array.isArray(messages)||messages.length>30||messages.some(m=>!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>8000))return res.status(400).json({error:'Mensagens inválidas.'});
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Configure OPENAI_API_KEY no servidor.'});
 try{const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},signal:AbortSignal.timeout(45000),body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',messages:[{role:'system',content:'Você é Kaique AI, um assistente útil que responde em português com clareza.'},...messages],max_tokens:1000})});
 const data=await response.json();if(!response.ok)return res.status(502).json({error:data.error?.message||'Falha no provedor de IA.'});res.json({reply:data.choices?.[0]?.message?.content||'Sem resposta.'});}catch(e){res.status(502).json({error:'Não foi possível conectar ao serviço de IA.'});}
});
app.post('/api/image',async(req,res)=>{
 const prompt=req.body?.prompt;if(typeof prompt!=='string'||!prompt.trim()||prompt.length>2000)return res.status(400).json({error:'Descrição inválida.'});
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Configure OPENAI_API_KEY no servidor.'});
 try{const r=await fetch('https://api.openai.com/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},signal:AbortSignal.timeout(90000),body:JSON.stringify({model:process.env.OPENAI_IMAGE_MODEL||'dall-e-3',prompt,size:'1024x1024',n:1})});const d=await r.json();if(!r.ok)return res.status(502).json({error:d.error?.message||'Erro ao gerar imagem.'});res.json({url:d.data?.[0]?.url});}catch{res.status(502).json({error:'Serviço de imagem indisponível.'});}
});
app.listen(Number(process.env.PORT)||3000,()=>console.log('Kaique AI iniciado na porta '+(process.env.PORT||3000)));
