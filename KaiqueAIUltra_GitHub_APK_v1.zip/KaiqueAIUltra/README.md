# Kaique AI Ultra v1.0 — Android

Aplicativo Android nativo em Kotlin + Jetpack Compose com chat real via APIs OpenAI, Google Gemini e Anthropic Claude.

## Recursos implementados
- Seleção entre três provedores, configuração manual do ID do modelo e chave de API.
- Chat com contexto da sessão e modos Geral, Programação e Pesquisa.
- Estados de carregamento e erros HTTP; interface escura Material 3.
- Chave de API mantida **apenas na memória**; não é persistida no dispositivo.

## Requisitos
- Android Studio recente com JDK 17, Android SDK Platform 35 e acesso à internet para sincronizar Gradle.
- Android 8.0+ (API 26).
- Chave válida e créditos/cota disponíveis no provedor escolhido.

## Gerar APK
1. Abra a pasta `KaiqueAIUltra` no Android Studio (File > Open).
2. Aguarde Gradle Sync e instale o Android SDK 35 caso solicitado.
3. No menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
5. Para distribuição, use Build > Generate Signed Bundle / APK, crie seu keystore e assine o APK.
6. Instale no dispositivo Android e configure a chave de API na engrenagem.

## Notas importantes
- **O arquivo ZIP contém código-fonte, não um APK compilado.** A compilação requer o Android Studio/Gradle com SDK.
- Os identificadores de modelos são exemplos e podem mudar. Consulte os modelos disponíveis e substitua no campo de configurações.
- O modo Pesquisa não navega na web: responde com conhecimento do modelo. Pesquisa com fontes requer integração adicional com busca.
- As chaves são usadas diretamente do celular nas APIs oficiais. Para um produto publicado, use um backend autenticado que proteja credenciais, limite gastos e aplique rate limiting. Nunca embuta chaves privadas no APK.
- O histórico é apenas da sessão; ao reiniciar, ele é perdido.
- As APIs podem cobrar por uso; não há desbloqueio de planos pagos.

## Endpoints
- OpenAI: POST https://api.openai.com/v1/chat/completions
- Gemini: POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
- Anthropic: POST https://api.anthropic.com/v1/messages

## Estrutura
- `app/src/main/java/com/kaique/aiultra/MainActivity.kt`: interface Compose.
- `app/src/main/java/com/kaique/aiultra/AiClient.kt`: clientes HTTP dos três provedores.
- `app/src/main/AndroidManifest.xml`: configuração e permissão de internet.

## Gerar APK pelo GitHub Actions (sem Android Studio)
1. Crie um repositorio GitHub e envie **o conteudo da pasta KaiqueAIUltra** para a raiz do repositorio (inclusive `.github/workflows/android-apk.yml`).
2. Abra **Actions > Gerar APK Android > Run workflow**.
3. Aguarde o job `build` terminar com sucesso.
4. Na pagina da execucao, em **Artifacts**, baixe `Kaique-AI-Ultra-APK`.
5. Extraia o ZIP do artifact e instale `app-debug.apk` no Android.

O workflow usa Java 17, Gradle 8.9 e Android SDK 35. O APK debug e para testes, nao para publicacao na Play Store. A compilacao ainda precisa ser validada na primeira execucao do Actions.
