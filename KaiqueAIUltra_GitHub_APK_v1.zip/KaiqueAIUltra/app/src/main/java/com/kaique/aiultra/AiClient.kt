package com.kaique.aiultra

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val role: String, val text: String)
enum class Provider(val label: String, val defaultModel: String) {
    OPENAI("OpenAI", "gpt-4.1-mini"), GEMINI("Gemini", "gemini-2.5-flash"), CLAUDE("Claude", "claude-sonnet-4-5")
}

object AiClient {
    suspend fun reply(provider: Provider, apiKey: String, model: String, messages: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Configure sua chave de API nas configurações." }
        val endpoint = when (provider) {
            Provider.OPENAI -> "https://api.openai.com/v1/chat/completions"
            Provider.GEMINI -> "https://generativelanguage.googleapis.com/v1beta/models/${java.net.URLEncoder.encode(model, "UTF-8")}:generateContent"
            Provider.CLAUDE -> "https://api.anthropic.com/v1/messages"
        }
        val body = when (provider) {
            Provider.OPENAI -> JSONObject().put("model", model).put("messages", JSONArray().apply {
                messages.forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
            })
            Provider.GEMINI -> JSONObject().put("contents", JSONArray().apply {
                messages.forEach { put(JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))) }
            })
            Provider.CLAUDE -> JSONObject().put("model", model).put("max_tokens", 2048)
                .put("messages", JSONArray().apply {
                    messages.forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
                })
        }
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            when (provider) {
                Provider.OPENAI -> setRequestProperty("Authorization", "Bearer $apiKey")
                Provider.GEMINI -> setRequestProperty("x-goog-api-key", apiKey)
                Provider.CLAUDE -> {
                    setRequestProperty("x-api-key", apiKey)
                    setRequestProperty("anthropic-version", "2023-06-01")
                }
            }
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val response = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException("Erro HTTP $code: ${response.take(500)}")
            val json = JSONObject(response)
            when (provider) {
                Provider.OPENAI -> json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                Provider.GEMINI -> json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
                Provider.CLAUDE -> json.getJSONArray("content").getJSONObject(0).getString("text")
            }
        } finally { conn.disconnect() }
    }
}
