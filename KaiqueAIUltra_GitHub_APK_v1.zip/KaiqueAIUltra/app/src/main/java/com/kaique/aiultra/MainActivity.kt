package com.kaique.aiultra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val Navy = Color(0xFF0B1020)
private val Purple = Color(0xFF9A7BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UltraScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UltraScreen() {
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(Provider.OPENAI) }
    var model by remember { mutableStateOf(provider.defaultModel) }
    var key by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Geral") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val listState = rememberLazyListState()
    val modes = listOf("Geral", "Programação", "Pesquisa")
    val systemHint = when (mode) {
        "Programação" -> "Você é um engenheiro de software experiente. Forneça código correto, explique dependências e testes."
        "Pesquisa" -> "Você é um assistente de pesquisa. Distinga fatos de hipóteses; nunca invente fontes ou alegue ter navegado na internet."
        else -> "Você é um assistente útil, rigoroso e claro."
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Color(0xFF171D32))) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(title = { Column { Text("KAIQUE AI ULTRA", fontWeight = FontWeight.Bold)
                Text("Assistente multi-IA", style = MaterialTheme.typography.labelSmall, color = Purple) } },
                actions = {
                    IconButton(onClick = { messages.clear(); error = "" }) { Icon(Icons.Default.Delete, "Limpar conversa") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Configurações") }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy))
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
                Text("Provedor", color = Color.LightGray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Provider.entries.forEach { p ->
                        FilterChip(selected = provider == p, onClick = { provider = p; model = p.defaultModel; messages.clear() }, label = { Text(p.label) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    modes.forEach { m -> FilterChip(selected = mode == m, onClick = { mode = m; messages.clear() }, label = { Text(m) }) }
                }
                Text("Modelo: $model", color = Color.LightGray, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                LazyColumn(state = listState, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (messages.isEmpty()) item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2340))) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Bem-vindo ao Kaique AI Ultra", fontWeight = FontWeight.Bold, color = Purple)
                                Spacer(Modifier.height(8.dp))
                                Text("Configure uma chave de API em ⚙ e escolha seu modelo para começar.")
                            }
                        }
                    }
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                            Card(modifier = Modifier.fillMaxWidth(0.93f), shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = if (msg.role == "user") Color(0xFF35305C) else Color(0xFF1A2340))) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(if (msg.role == "user") "Você" else provider.label, color = Purple, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(5.dp)); Text(msg.text)
                                }
                            }
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                    OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Digite sua mensagem...") }, maxLines = 5, shape = RoundedCornerShape(20.dp))
                    FilledIconButton(enabled = !busy && prompt.isNotBlank(), onClick = {
                        val current = prompt.trim()
                        prompt = ""; error = ""
                        messages.add(ChatMessage("user", current))
                        busy = true
                        scope.launch {
                            try {
                                val history = listOf(ChatMessage("user", "Instrução de comportamento: $systemHint")) + messages.toList()
                                val answer = AiClient.reply(provider, key.trim(), model.trim(), history)
                                messages.add(ChatMessage("assistant", answer))
                                listState.animateScrollToItem(messages.lastIndex)
                            } catch (e: Exception) {
                                error = e.message ?: "Falha de conexão"
                            } finally { busy = false }
                        }
                    }) { Icon(Icons.AutoMirrored.Filled.Send, "Enviar") }
                }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false },
            title = { Text("Configurações da IA") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Chave de API para ${provider.label}. Mantida somente na memória enquanto o app estiver aberto; não é salva no aparelho.")
                OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("API Key") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Identificador do modelo") }, singleLine = true)
                Text("Atenção: chamadas de API podem gerar cobranças. Para produção, use um backend com autenticação e controle de custos.", style = MaterialTheme.typography.bodySmall)
            } }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Concluir") } })
    }
}
