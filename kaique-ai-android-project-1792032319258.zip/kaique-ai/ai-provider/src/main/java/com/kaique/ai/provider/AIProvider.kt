package com.kaique.ai.provider

import com.kaique.ai.core.model.Message
import kotlinx.coroutines.flow.Flow

interface AIProvider {
    val name: String
    fun streamChat(
        messages: List<Message>,
        model: String,
        temperature: Float,
        maxTokens: Int
    ): Flow<String>

    suspend fun sendRequest(
        messages: List<Message>,
        model: String,
        temperature: Float,
        maxTokens: Int
    ): String
}
