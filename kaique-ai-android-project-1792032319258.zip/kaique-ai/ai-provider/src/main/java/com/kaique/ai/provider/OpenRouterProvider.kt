package com.kaique.ai.provider

import com.kaique.ai.core.config.OpenRouterConfig
import com.kaique.ai.core.model.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.util.concurrent.TimeUnit

class OpenRouterProvider(
    private val config: OpenRouterConfig,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
) : AIProvider {

    override val name: String = "OpenRouter"

    override fun streamChat(
        messages: List<Message>,
        model: String,
        temperature: Float,
        maxTokens: Int
    ): Flow<String> = flow {
        val apiKey = config.apiKey.trim()
        if (apiKey.isBlank()) {
            throw IllegalStateException("Chave OpenRouterConfig.apiKey não configurada na UI/Settings.")
        }

        val jsonBody = JSONObject().apply {
            put("model", model)
            put("stream", true)
            put("temperature", temperature.toDouble())
            put("max_tokens", maxTokens)

            val messagesArray = JSONArray()
            for (m in messages) {
                messagesArray.put(JSONObject().apply {
                    put("role", m.role)
                    put("content", m.content)
                })
            }
            put("messages", messagesArray)
        }

        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("HTTP-Referer", "https://kaique.ai.app")
            .addHeader("X-Title", "KAIQUE AI Android")
            .addHeader("Content-Type", "application/json")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()

        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Sem detalhes"
            when (response.code) {
                401 -> throw IOException("Erro 401: Chave de API inválida no OpenRouter.")
                402 -> throw IOException("Erro 402: Pagamento necessário / Créditos insuficientes.")
                429 -> throw IOException("Erro 429: Rate Limit excedido no OpenRouter. Tente novamente em breve.")
                500 -> throw IOException("Erro 500: Falha no servidor remoto do OpenRouter.")
                else -> throw IOException("Erro HTTP ${response.code}: $errorBody")
            }
        }

        val source = response.body?.charStream() ?: throw IOException("Corpo da resposta vazio")
        val reader = BufferedReader(source)
        var line: String?

        while (reader.readLine().also { line = it } != null) {
            val currentLine = line?.trim() ?: continue
            if (currentLine.startsWith("data: ")) {
                val dataStr = currentLine.removePrefix("data: ").trim()
                if (dataStr == "[DONE]") break
                try {
                    val obj = JSONObject(dataStr)
                    val choices = obj.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val delta = choices.getJSONObject(0).optJSONObject("delta")
                        val content = delta?.optString("content")
                        if (!content.isNullOrEmpty()) {
                            emit(content)
                        }
                    }
                } catch (e: Exception) {
                    // Ignora chunks parciais de streaming
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendRequest(
        messages: List<Message>,
        model: String,
        temperature: Float,
        maxTokens: Int
    ): String {
        val apiKey = config.apiKey.trim()
        if (apiKey.isBlank()) throw IllegalStateException("Chave OpenRouter não configurada.")

        val jsonBody = JSONObject().apply {
            put("model", model)
            put("stream", false)
            put("temperature", temperature.toDouble())
            put("max_tokens", maxTokens)
            val msgs = JSONArray()
            for (m in messages) {
                msgs.put(JSONObject().apply {
                    put("role", m.role)
                    put("content", m.content)
                })
            }
            put("messages", msgs)
        }

        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("HTTP-Referer", "https://kaique.ai.app")
            .addHeader("X-Title", "KAIQUE AI Android")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            throw IOException("Erro HTTP ${response.code}: ${response.body?.string()}")
        }
        val resObj = JSONObject(response.body?.string() ?: "{}")
        return resObj.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}
