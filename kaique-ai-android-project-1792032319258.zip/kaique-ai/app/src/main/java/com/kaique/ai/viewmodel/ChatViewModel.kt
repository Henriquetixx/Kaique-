package com.kaique.ai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kaique.ai.core.config.OpenRouterConfig
import com.kaique.ai.core.data.ChatDao
import com.kaique.ai.core.model.ChatSession
import com.kaique.ai.core.model.Message
import com.kaique.ai.provider.OpenRouterProvider
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatUiState(
    val currentSessionId: String? = null,
    val isStreaming: Boolean = false,
    val errorMessage: String? = null,
    val streamingContent: String = ""
)

class ChatViewModel(
    private val chatDao: ChatDao,
    private val openRouterConfig: OpenRouterConfig
) : ViewModel() {

    val sessions: StateFlow<List<ChatSession>> = chatDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val provider = OpenRouterProvider(openRouterConfig)

    fun createSession(title: String = "Nova Conversa") {
        viewModelScope.launch {
            val session = ChatSession(title = title)
            chatDao.insertSession(session)
            _uiState.update { it.copy(currentSessionId = session.id) }
        }
    }

    fun selectSession(sessionId: String) {
        _uiState.update { it.copy(currentSessionId = sessionId, errorMessage = null) }
    }

    fun sendMessage(content: String, history: List<Message>) {
        val sessionId = _uiState.value.currentSessionId ?: return
        if (content.isBlank()) return

        viewModelScope.launch {
            val userMsg = Message(sessionId = sessionId, role = "user", content = content)
            chatDao.insertMessage(userMsg)
            chatDao.updateSessionTimestamp(sessionId)

            _uiState.update { it.copy(isStreaming = true, streamingContent = "", errorMessage = null) }

            val fullConversation = history + userMsg
            val accumulated = StringBuilder()

            try {
                provider.streamChat(
                    messages = fullConversation,
                    model = openRouterConfig.defaultModel,
                    temperature = openRouterConfig.temperature,
                    maxTokens = openRouterConfig.maxTokens
                ).catch { err ->
                    _uiState.update { it.copy(isStreaming = false, errorMessage = err.message) }
                    chatDao.insertMessage(Message(
                        sessionId = sessionId,
                        role = "assistant",
                        content = "Erro: ${err.message}",
                        hasError = true,
                        errorMessage = err.message
                    ))
                }.collect { chunk ->
                    accumulated.append(chunk)
                    _uiState.update { it.copy(streamingContent = accumulated.toString()) }
                }

                // Finaliza mensagem no banco
                val assistantMsg = Message(
                    sessionId = sessionId,
                    role = "assistant",
                    content = accumulated.toString(),
                    model = openRouterConfig.defaultModel,
                    provider = "openrouter"
                )
                chatDao.insertMessage(assistantMsg)
                _uiState.update { it.copy(isStreaming = false, streamingContent = "") }

            } catch (e: Exception) {
                _uiState.update { it.copy(isStreaming = false, errorMessage = e.message) }
            }
        }
    }
}
