package com.kaique.ai.core.backup

import com.kaique.ai.core.data.ChatDao
import com.kaique.ai.core.model.ChatSession
import com.kaique.ai.core.model.Message
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class FullBackupData(
    val app: String = "KAIQUE AI",
    val creator: String = "Kaique Henrique Dias da Silva",
    val exportedAt: Long = System.currentTimeMillis(),
    val sessions: List<ChatSession>,
    val messages: List<Message>
)

class BackupManager(private val chatDao: ChatDao) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    suspend fun createBackupJson(): String {
        val sessions = chatDao.getAllSessions().first()
        val allMessages = mutableListOf<Message>()
        for (session in sessions) {
            val msgs = chatDao.getMessagesForSession(session.id).first()
            allMessages.addAll(msgs)
        }
        val backup = FullBackupData(sessions = sessions, messages = allMessages)
        return json.encodeToString(backup)
    }

    suspend fun restoreFromJson(backupJson: String): Boolean {
        return try {
            val backup = json.decodeFromString<FullBackupData>(backupJson)
            for (session in backup.sessions) {
                chatDao.insertSession(session)
            }
            for (msg in backup.messages) {
                chatDao.insertMessage(msg)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
