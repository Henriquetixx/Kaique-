package com.kaique.ai.core.config

import android.content.Context
import android.content.SharedPreferences

class OpenRouterConfig(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("kaique_ai_secure_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("openrouter_api_key", "") ?: ""
        set(value) = prefs.edit().putString("openrouter_api_key", value.trim()).apply()

    var defaultModel: String
        get() = prefs.getString("openrouter_model", "meta-llama/llama-3.3-70b-instruct") ?: "meta-llama/llama-3.3-70b-instruct"
        set(value) = prefs.edit().putString("openrouter_model", value.trim()).apply()

    var temperature: Float
        get() = prefs.getFloat("openrouter_temp", 0.7f)
        set(value) = prefs.edit().putFloat("openrouter_temp", value).apply()

    var maxTokens: Int
        get() = prefs.getInt("openrouter_max_tokens", 2048)
        set(value) = prefs.edit().putInt("openrouter_max_tokens", value).apply()

    fun isConfigured(): Boolean = apiKey.isNotBlank()
}
