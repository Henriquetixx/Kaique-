package com.kaique.ai.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "chat_sessions")
data class ChatSession(
    @PrimaryKey
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val preferredProvider: String = "openrouter",
    val preferredModel: String = "meta-llama/llama-3.3-70b-instruct"
)
