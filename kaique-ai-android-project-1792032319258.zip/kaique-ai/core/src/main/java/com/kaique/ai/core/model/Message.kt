package com.kaique.ai.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey
    val id: String = java.util.UUID.randomUUID().toString(),
    val sessionId: String,
    val role: String, // "user", "assistant", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val model: String? = null,
    val provider: String? = null,
    val searchSourcesJson: String? = null, // JSON serializado de SearchResult
    val hasError: Boolean = false,
    val errorMessage: String? = null
)
