package com.kaique.ai.research

import kotlinx.serialization.Serializable
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

@Serializable
data class SearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val source: String = "Web"
)

class WebSearch(
    private val client: OkHttpClient = OkHttpClient()
) {
    fun search(query: String): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        val url = "https://api.duckduckgo.com/?q=${java.net.URLEncoder.encode(query, "UTF-8")}&format=json&no_html=1"

        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "KAIQUE-AI-Android/1.0")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            throw IOException("Erro ao pesquisar: HTTP ${response.code}")
        }

        val jsonStr = response.body?.string() ?: return emptyList()
        val obj = JSONObject(jsonStr)

        val abstractText = obj.optString("Abstract")
        val abstractUrl = obj.optString("AbstractURL")
        val heading = obj.optString("Heading")

        if (abstractText.isNotEmpty() && abstractUrl.isNotEmpty()) {
            results.add(SearchResult(
                title = if (heading.isNotEmpty()) heading else query,
                url = abstractUrl,
                snippet = abstractText,
                source = obj.optString("AbstractSource", "DuckDuckGo")
            ))
        }

        val relatedTopics = obj.optJSONArray("RelatedTopics")
        if (relatedTopics != null) {
            for (i in 0 until minOf(relatedTopics.length(), 5)) {
                val item = relatedTopics.optJSONObject(i) ?: continue
                val text = item.optString("Text")
                val firstUrl = item.optString("FirstURL")
                if (text.isNotEmpty() && firstUrl.isNotEmpty()) {
                    results.add(SearchResult(
                        title = text.split(" - ").firstOrNull() ?: text.take(40),
                        url = firstUrl,
                        snippet = text,
                        source = "Web"
                    ))
                }
            }
        }
        return results
    }
}
