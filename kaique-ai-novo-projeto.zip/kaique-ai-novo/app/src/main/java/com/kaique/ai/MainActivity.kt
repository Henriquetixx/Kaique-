package com.kaique.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var messages: LinearLayout
    private lateinit var entry: EditText
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var send: Button
    private lateinit var speech: TextToSpeech
    private val history = JSONArray()
    private val prefs by lazy { getSharedPreferences("kaique_config", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(14,17,23)
        window.navigationBarColor = Color.rgb(14,17,23)
        speech = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(14,17,23)); setPadding(18,12,18,12) }
        val title = TextView(this).apply { text = "✦ Kaique AI"; textSize = 25f; setTextColor(Color.WHITE); setPadding(6,8,0,14) }
        root.addView(title)
        val settings = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        key = EditText(this).apply { hint = "Chave OpenRouter (salva só neste aparelho)"; setSingleLine(true); setText(prefs.getString("api_key", "")); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); inputType = 129 }
        model = EditText(this).apply { hint = "Modelo OpenRouter"; setSingleLine(true); setText(prefs.getString("model", "openai/gpt-4o-mini")); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        settings.addView(key); settings.addView(model)
        root.addView(settings)
        val scroll = ScrollView(this).apply { fillViewport = true }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(5,12,5,12) }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        addMessage("Kaique AI", "Olá! Configure sua chave OpenRouter e comece a conversar. Use o microfone para ditar e o botão 🔊 para ouvir minhas respostas.")
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        entry = EditText(this).apply { hint = "Pergunte qualquer coisa..."; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); minLines = 1; maxLines = 3 }
        bottom.addView(entry, LinearLayout.LayoutParams(0,-2,1f))
        val mic = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        bottom.addView(mic)
        send = Button(this).apply { text = "➤"; setOnClickListener { ask() } }
        bottom.addView(send)
        root.addView(bottom)
        setContentView(root)
    }
    private fun addMessage(who:String, value:String) {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(if (who=="Você") Color.rgb(39,54,73) else Color.rgb(30,35,45)) }
        val heading = TextView(this).apply { text=who; setTextColor(Color.rgb(122,204,181)); textSize=13f }
        val body = TextView(this).apply { text=value; setTextColor(Color.WHITE); textSize=16f; setPadding(0,7,0,0); setTextIsSelectable(true) }
        block.addView(heading); block.addView(body)
        if (who=="Kaique AI") { val speak = Button(this).apply { text="🔊 Ouvir"; setOnClickListener { speech.speak(value,TextToSpeech.QUEUE_FLUSH,null,"reply") } }; block.addView(speak) }
        messages.addView(block,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=12 })
        (messages.parent as? ScrollView)?.post { (messages.parent as ScrollView).fullScroll(View.FOCUS_DOWN) }
    }
    private fun ask() {
        val prompt=entry.text.toString().trim(); val token=key.text.toString().trim(); val modelName=model.text.toString().trim()
        if (prompt.isEmpty()) return
        if (token.isEmpty()) { Toast.makeText(this,"Informe a chave OpenRouter",Toast.LENGTH_LONG).show(); return }
        prefs.edit().putString("api_key",token).putString("model",modelName).apply()
        entry.setText(""); addMessage("Você",prompt); send.isEnabled=false
        history.put(JSONObject().put("role","user").put("content",prompt))
        thread {
            try {
                val conn=URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
                conn.requestMethod="POST"; conn.connectTimeout=20000; conn.readTimeout=90000; conn.doOutput=true
                conn.setRequestProperty("Authorization","Bearer $token"); conn.setRequestProperty("Content-Type","application/json")
                conn.setRequestProperty("HTTP-Referer","https://github.com/"); conn.setRequestProperty("X-Title","Kaique AI")
                val req=JSONObject().put("model",modelName).put("messages",JSONArray().put(JSONObject().put("role","system").put("content","Você é Kaique AI, assistente útil e claro. Responda em português brasileiro.")))
                for(i in 0 until history.length()) req.getJSONArray("messages").put(history.getJSONObject(i))
                conn.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
                val code=conn.responseCode
                val response=(if(code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                if(code !in 200..299) throw Exception("HTTP $code: ${response.take(400)}")
                val answer=JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","Sem resposta")
                history.put(JSONObject().put("role","assistant").put("content",answer))
                runOnUiThread { addMessage("Kaique AI",answer); send.isEnabled=true }
            } catch(e:Exception) { runOnUiThread { addMessage("Erro",e.message ?: "Falha na conexão"); send.isEnabled=true } }
        }
    }
    private fun listen() { try { val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR") }; startActivityForResult(intent,55) } catch(e:Exception) { Toast.makeText(this,"Reconhecimento de voz indisponível",Toast.LENGTH_LONG).show() } }
    @Deprecated("Uses legacy Activity result for compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==55 && resultCode==RESULT_OK) { val text=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull(); if(text!=null) entry.setText(text) } }
    override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) speech.language=Locale("pt","BR") }
    override fun onDestroy() { speech.stop(); speech.shutdown(); super.onDestroy() }
}
