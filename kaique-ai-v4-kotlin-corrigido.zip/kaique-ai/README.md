# Kaique AI — revisão Android com Painel Hacker

Projeto Android nativo de demonstração / desenvolvimento em Kotlin, Jetpack Compose e Material 3.

## Implementado nesta revisão

- Menu lateral que navega entre **Chat**, **Painel Hacker** e **Configurações**.
- Chat textual por OpenRouter usando modelo padrão `openrouter/free` e chave informada pelo usuário.
- Campo de API protegido visualmente e armazenamento local criptografado (EncryptedSharedPreferences).
- Voz: entrada via app de reconhecimento de fala disponível no Android; leitura TTS instalada no dispositivo.
- Painel Hacker defensivo: identificação de Wi-Fi/rede móvel, estado da permissão de microfone, resolução DNS e requisição HTTPS para domínio digitado.
- Tratamento de erros HTTP do chat sem divulgar chaves.

## Limitações conhecidas

- APK **não compilado nem testado em dispositivo** nesta revisão. A compilação deve ser validada no Android SDK 35.
- Histórico de chat só em memória nesta revisão; não sobrevive ao fechamento do aplicativo.
- Recursos de imagens, pesquisa web e leitura de documentos são protótipos e foram preservados como código, mas **não fazem parte do build** até serem integrados corretamente.
- Apenas chat textual por API OpenRouter: não há streaming incremental, nem imagens/vídeos gerados, nem voz neural remota.
- Painel não faz varredura de rede nem auditoria invasiva; diagnósticos restritos a domínios fornecidos pelo usuário.
- Este projeto não deve ser publicado na Play Store sem testes, revisão de privacidade e adequações de segurança.

## Compilação

- Java 17
- Android SDK 35 e Build Tools 35.0.0
- Gradle 8.9
- AGP 8.7.3 / Kotlin 2.0.21

Na raiz do projeto execute `gradle :app:assembleDebug`. O APK deverá aparecer em `app/build/outputs/apk/debug/app-debug.apk` somente **se o build for bem-sucedido**.

Há um workflow em `.github/workflows/build-apk.yml`. É necessário copiar os arquivos extraídos para a **raiz** do repositório para que o GitHub Actions o reconheça.

## Segurança

Nunca envie suas chaves ao repositório. Esta revisão não inclui chaves privadas.
