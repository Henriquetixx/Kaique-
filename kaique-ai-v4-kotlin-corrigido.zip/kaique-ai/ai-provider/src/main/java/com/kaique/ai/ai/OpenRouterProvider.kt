package com.kaique.ai.ai

import com.kaique.ai.core.Message
import com.kaique.ai.core.OpenRouterConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Cliente de chat textual; execute chat() em Dispatchers.IO. */
class OpenRouterProvider(private val config: OpenRouterConfig) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        // Não habilitar interceptors BODY: poderiam registrar credenciais.
        .build()

    fun chat(messages: List<Message>): String {
        require(config.apiKey.isNotBlank()) { "Configure sua chave OpenRouter em Configurações." }
        val payload = JSONObject().apply {
            put("model", config.model)
            put("temperature", config.temperature.toDouble())
            put("max_tokens", config.maxTokens)
            put("messages", JSONArray().apply {
                messages.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role.name.lowercase())
                        put("content", msg.content)
                    })
                }
            })
        }
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer ${config.apiKey}")
            .header("Content-Type", "application/json")
            .header("X-Title", "Kaique AI")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val readable = when (response.code) {
                    400 -> "solicitação inválida para este modelo"
                    401 -> "chave de API inválida"
                    403 -> "acesso ao modelo negado"
                    429 -> "limite de uso atingido; tente novamente depois"
                    in 500..599 -> "serviço temporariamente indisponível"
                    else -> "erro de conexão com o modelo"
                }
                throw IllegalStateException("OpenRouter ${response.code}: $readable")
            }
            val responseText = response.body?.string().orEmpty()
            val json = JSONObject(responseText)
            val choices = json.optJSONArray("choices")
            val reply = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            if (reply.isBlank()) throw IllegalStateException("Modelo não retornou texto.")
            return reply
        }
    }
}
