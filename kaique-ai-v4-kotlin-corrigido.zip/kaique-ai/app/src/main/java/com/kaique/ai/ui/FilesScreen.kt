package com.kaique.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

@Composable
fun FilesScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Documentos", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Selecione PDF, TXT ou outros arquivos para leitura e resumo.")
        Text("Leitura de PDF via Android PdfRenderer; resumo requer API configurada.")
    }
}
