package com.kaique.ai.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.URL
import javax.net.ssl.HttpsURLConnection

private val cyberGreen = Color(0xFF39FF14)
private val cyberBackground = Color(0xFF101418)
private val cyberSurface = Color(0xFF20272A)

@Composable
fun PainelHackerScreen(modifier: Modifier = Modifier, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var host by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Informe um domínio que você administra ou tem autorização para testar.") }
    var working by remember { mutableStateOf(false) }
    val network = currentNetworkType(context)
    val microphone = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    Column(
        modifier.fillMaxSize().background(cyberBackground).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("KAIQUE CYBER X", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.headlineSmall, color = cyberGreen)
        Text("Diagnósticos defensivos — sem varredura automática", color = Color.LightGray)
        CyberCard("Status do dispositivo") {
            Text("Conexão: $network", color = Color.White)
            Text("Microfone autorizado: ${if (microphone) "sim" else "não"}", color = Color.White)
            Text("Conexões HTTPS: validação TLS padrão do Android", color = Color.White)
        }
        CyberCard("DNS e HTTPS") {
            OutlinedTextField(
                value = host,
                onValueChange = { host = it },
                label = { Text("Domínio autorizado (exemplo.com)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedBorderColor = cyberGreen, focusedLabelColor = cyberGreen,
                    unfocusedLabelColor = Color.LightGray
                )
            )
            Spacer(Modifier.height(8.dp))
            Button(
                enabled = !working && host.isNotBlank(),
                onClick = {
                    val target = host.trim()
                    working = true
                    scope.launch {
                        output = try {
                            withContext(Dispatchers.IO) { diagnosticFor(target) }
                        } catch (e: Exception) {
                            "Falha no diagnóstico: ${e.message ?: "verifique o domínio e sua conexão"}"
                        } finally {
                            working = false
                        }
                    }
                }
            ) { Text(if (working) "Verificando..." else "Diagnosticar") }
            Text(output, color = Color(0xFFE4F2E6), fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 12.dp))
        }
        CyberCard("Sobre os recursos") {
            Text("Disponíveis: estado da conexão, permissões locais, resolução DNS e teste HTTPS para domínio informado.", color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text("Ainda não implementados: análise de logs externos, relatórios PDF, auditoria automática e terminal completo.", color = Color.LightGray)
        }
        OutlinedButton(onClick = onBack) { Text("Voltar ao chat", color = cyberGreen) }
    }
}

@Composable
private fun CyberCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = cyberSurface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = cyberGreen, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

private fun currentNetworkType(context: Context): String {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        ?: return "indisponível"
    val caps = manager.getNetworkCapabilities(manager.activeNetwork) ?: return "sem rede"
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "rede móvel"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "outra rede"
    }
}

private fun diagnosticFor(input: String): String {
    // Somente DNS e uma requisição HTTPS normal; não faz scan de portas.
    val hostname = input.trim().removePrefix("https://").removePrefix("http://")
        .substringBefore('/').substringBefore(':')
    if (!hostname.matches(Regex("(?i)^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$")) || !hostname.contains('.')) {
        throw IllegalArgumentException("Digite um domínio válido, sem caminho nem porta.")
    }
    val addresses = InetAddress.getAllByName(hostname).joinToString { it.hostAddress.orEmpty() }
    val conn = URL("https://$hostname/").openConnection() as HttpsURLConnection
    conn.connectTimeout = 8000
    conn.readTimeout = 8000
    conn.instanceFollowRedirects = false
    return try {
        conn.connect()
        "Domínio: $hostname\nDNS: $addresses\nHTTPS: ${conn.responseCode}\nTLS: ${conn.cipherSuite}"
    } finally {
        conn.disconnect()
    }
}
