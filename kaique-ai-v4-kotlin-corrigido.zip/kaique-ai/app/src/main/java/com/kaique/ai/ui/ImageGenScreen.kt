package com.kaique.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ImageGenScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Geração de imagens", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("Descrição da imagem") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { }) { Text("Gerar imagem") }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Requer API de geração real (OpenAI DALL-E / Midjourney / Stable Diffusion). Não simula resultados.", color = MaterialTheme.colorScheme.outline)
    }
}
