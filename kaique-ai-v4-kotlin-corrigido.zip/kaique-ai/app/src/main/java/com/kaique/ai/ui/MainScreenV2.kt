package com.kaique.ai.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kaique.ai.ai.OpenRouterProvider
import com.kaique.ai.core.Message
import com.kaique.ai.core.OpenRouterConfig
import com.kaique.ai.core.SecureConfigStorage
import com.kaique.ai.voice.VoiceModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private enum class Page { CHAT, CYBER, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreenV2() {
    val context = LocalContext.current
    val storage = remember(context) { SecureConfigStorage(context) }
    var config by remember { mutableStateOf(storage.loadConfig()) }
    val messages = remember { mutableStateListOf<Message>() }
    var input by rememberSaveable { mutableStateOf("") }
    var page by rememberSaveable { mutableStateOf(Page.CHAT) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val voice = remember(context) { VoiceModule(context) }
    DisposableEffect(voice) { onDispose { voice.release() } }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!recognized.isNullOrBlank()) input = recognized
    }

    fun send() {
        val content = input.trim()
        if (content.isBlank() || loading) return
        messages.add(Message(role = Message.Role.User, content = content))
        input = ""
        val snapshot = messages.toList()
        val currentConfig = config
        loading = true
        scope.launch {
            try {
                val answer = withContext(Dispatchers.IO) {
                    OpenRouterProvider(currentConfig).chat(snapshot)
                }
                messages.add(Message(role = Message.Role.Assistant, content = answer))
            } catch (e: Exception) {
                messages.add(Message(
                    role = Message.Role.Assistant,
                    content = "Não foi possível responder. ${e.message ?: "Verifique a conexão."}",
                    error = e.message
                ))
            } finally {
                loading = false
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(18.dp))
                Text("Kaique AI", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp))
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Add, null) }, label = { Text("Nova conversa") },
                    selected = false,
                    onClick = { messages.clear(); input = ""; page = Page.CHAT; scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Chat") },
                    selected = page == Page.CHAT,
                    onClick = { page = Page.CHAT; scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Security, null) }, label = { Text("Painel Hacker") },
                    selected = page == Page.CYBER,
                    onClick = { page = Page.CYBER; scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Configurações") },
                    selected = page == Page.SETTINGS,
                    onClick = { page = Page.SETTINGS; scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Spacer(Modifier.height(12.dp))
                HorizontalDivider()
                Text("Kaique Cyber X: diagnósticos defensivos", style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(when (page) { Page.CHAT -> "Kaique AI"; Page.CYBER -> "Painel Hacker"; Page.SETTINGS -> "Configurações" }) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Abrir menu")
                        }
                    }
                )
            }
        ) { inner ->
            when (page) {
                Page.CYBER -> PainelHackerScreen(
                    modifier = Modifier.padding(inner),
                    onBack = { page = Page.CHAT }
                )
                Page.SETTINGS -> Box(Modifier.padding(inner)) {
                    SettingsScreen(config) { newConfig ->
                        try {
                            storage.saveConfig(newConfig)
                            config = newConfig
                            Toast.makeText(context, "Configurações salvas", Toast.LENGTH_SHORT).show()
                            page = Page.CHAT
                        } catch (e: Exception) {
                            Toast.makeText(context, "Falha ao salvar configurações", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                Page.CHAT -> Column(Modifier.padding(inner).fillMaxSize()) {
                    if (messages.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                                Text("Bem-vindo ao Kaique AI", style = MaterialTheme.typography.headlineMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("Escolha um modelo e comece a conversar.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentPadding = PaddingValues(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                ChatBubble(msg, onCopy = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Kaique AI", it))
                                }, onSpeak = { voice.speak(msg.content) })
                            }
                            if (loading) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
                        }
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag("pt-BR").toLanguageTag())
                            }
                            try { speechLauncher.launch(speechIntent) }
                            catch (_: Exception) { Toast.makeText(context, "Reconhecimento de voz indisponível", Toast.LENGTH_LONG).show() }
                        }) { Icon(Icons.Default.Mic, contentDescription = "Ditar mensagem") }
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f), maxLines = 4,
                            placeholder = { Text("Mensagem") }
                        )
                        IconButton(onClick = { send() }, enabled = input.isNotBlank() && !loading) {
                            Icon(Icons.Default.Send, contentDescription = "Enviar")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: Message, onCopy: (String) -> Unit, onSpeak: () -> Unit) {
    val user = message.role == Message.Role.User
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(message.content)
                Spacer(Modifier.height(4.dp))
                Row {
                    TextButton(onClick = { onCopy(message.content) }) { Text("Copiar") }
                    if (!user) TextButton(onClick = onSpeak) { Text("Ouvir") }
                }
            }
        }
    }
}
