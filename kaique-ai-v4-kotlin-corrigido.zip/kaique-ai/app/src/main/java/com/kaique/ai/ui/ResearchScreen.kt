package com.kaique.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ResearchScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Pesquisa profunda", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Pesquisar na web") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { }) { Text("Pesquisar") }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Requer API de pesquisa real (Brave Search / DuckDuckGo / SerpApi). Se indisponível, desativado.", color = MaterialTheme.colorScheme.outline)
    }
}
