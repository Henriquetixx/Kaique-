package com.kaique.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.kaique.ai.core.OpenRouterConfig

@Composable
fun SettingsScreen(config: OpenRouterConfig, onSave: (OpenRouterConfig) -> Unit) {
    var apiKey by remember(config) { mutableStateOf(config.apiKey) }
    var model by remember(config) { mutableStateOf(config.model) }
    var temperature by remember(config) { mutableStateOf(config.temperature.toString()) }
    var maxTokens by remember(config) { mutableStateOf(config.maxTokens.toString()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Configurações de IA", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = apiKey, onValueChange = { apiKey = it },
            label = { Text("Chave OpenRouter") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = model, onValueChange = { model = it },
            label = { Text("Modelo") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = temperature, onValueChange = { temperature = it },
            label = { Text("Temperatura") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = maxTokens, onValueChange = { maxTokens = it },
            label = { Text("Máximo de tokens de resposta") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                onSave(config.copy(
                    apiKey = apiKey.trim(), model = model.trim(),
                    temperature = (temperature.toFloatOrNull() ?: 0.7f).coerceIn(0f, 2f),
                    maxTokens = (maxTokens.toIntOrNull() ?: 1024).coerceIn(64, 4096)
                ))
            }, enabled = model.isNotBlank(), modifier = Modifier.fillMaxWidth()
        ) { Text("Salvar") }
        Spacer(Modifier.height(10.dp))
        Text("Sua chave é armazenada localmente em preferências criptografadas. Não inclua chaves no GitHub.", style = MaterialTheme.typography.bodySmall)
    }
}
