package com.kaique.ai.core

import org.json.JSONArray
import org.json.JSONObject

/** Exportação local de sessões; não inclui tokens ou chaves de API. */
object BackupManager {
    fun backupSessions(sessions: List<ChatSession>): String = JSONArray().apply {
        sessions.forEach { session ->
            put(JSONObject().apply {
                put("id", session.id)
                put("title", session.title)
                put("createdAt", session.createdAt)
                put("messages", JSONArray().apply {
                    session.messages.forEach { msg ->
                        put(JSONObject().apply {
                            put("id", msg.id)
                            put("role", msg.role.name)
                            put("content", msg.content)
                            put("timestamp", msg.timestamp)
                        })
                    }
                })
            })
        }
    }.toString()

    fun restoreSessions(json: String): List<ChatSession> {
        val array = JSONArray(json)
        return (0 until array.length()).map { index ->
            val obj = array.getJSONObject(index)
            val messages = obj.getJSONArray("messages")
            ChatSession(
                id = obj.getString("id"),
                title = obj.optString("title", "Nova conversa"),
                createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                messages = (0 until messages.length()).map { idx ->
                    val msg = messages.getJSONObject(idx)
                    Message(
                        id = msg.getString("id"),
                        role = Message.Role.valueOf(msg.getString("role")),
                        content = msg.getString("content"),
                        timestamp = msg.optLong("timestamp", System.currentTimeMillis())
                    )
                }.toMutableList()
            )
        }
    }
}
