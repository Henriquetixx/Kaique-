package com.kaique.ai.core

import java.util.UUID

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val error: String? = null
) {
    enum class Role { User, Assistant, System }
}

data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Nova conversa",
    val messages: MutableList<Message> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis()
)

data class OpenRouterConfig(
    val apiKey: String = "",
    val model: String = "openrouter/free",
    val temperature: Float = 0.7f,
    val maxTokens: Int = 1024,
    val streaming: Boolean = true
)
