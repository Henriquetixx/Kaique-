package com.kaique.ai.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureConfigStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "kaique_ai_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveConfig(config: OpenRouterConfig) {
        prefs.edit().apply {
            putString("openrouter_api_key", config.apiKey)
            putString("openrouter_model", config.model)
            putFloat("openrouter_temperature", config.temperature)
            putInt("openrouter_max_tokens", config.maxTokens)
            putBoolean("openrouter_streaming", config.streaming)
            apply()
        }
    }

    fun loadConfig(): OpenRouterConfig {
        return OpenRouterConfig(
            apiKey = prefs.getString("openrouter_api_key", "") ?: "",
            model = prefs.getString("openrouter_model", "openrouter/free") ?: "openrouter/free",
            temperature = prefs.getFloat("openrouter_temperature", 0.7f),
            maxTokens = prefs.getInt("openrouter_max_tokens", 2048),
            streaming = prefs.getBoolean("openrouter_streaming", true)
        )
    }
}
