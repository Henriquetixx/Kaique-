package com.kaique.ai.files

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FileManager(private val context: Context) {

    suspend fun readTextFromUri(uri: Uri): String = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader().readText()
        } ?: throw IllegalArgumentException("Não foi possível abrir o arquivo")
    }

    fun extractPdfText(uri: Uri): String {
        // Estrutura para integração com biblioteca PDF (ex.: iText ou PDFBox)
        // Em produção completa, usar PdfRenderer (Android API 21+) ou biblioteca nativa.
        val renderer = android.graphics.pdf.PdfRenderer(
            android.os.ParcelFileDescriptor.open(uri, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        )
        val page = renderer.openPage(0)
        val text = page.renderToBitmap()?.let { bitmap ->
            // Em produção, usar OCR ou parser PDF; aqui retorna placeholder funcional
            "[PDF extraído — página 1 de ${renderer.pageCount}]. Utilize iText ou PDFBox para extração completa."
        } ?: "Não foi possível renderizar PDF"
        page.close()
        renderer.close()
        return text
    }

    fun shareFile(uri: Uri) {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Compartilhar arquivo"))
    }
}
