package com.kaique.ai.image

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ImageGenerator(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(prompt: String, size: String = "1024x1024"): String = withContext(Dispatchers.IO) {
        val url = "https://openrouter.ai/api/v1/images/generations"
        val body = JSONObject().apply {
            put("prompt", prompt)
            put("n", 1)
            put("size", size)
            put("response_format", "url")
        }.toString()
        val request = Request.Builder()
            .url(url)
            .post(okhttp3.RequestBody.create("application/json".toMediaType(), body))
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()
        val response = client.newCall(request).execute()
        val json = JSONObject(response.body?.string() ?: "{}")
        val urlResult = json.getJSONArray("data").getJSONObject(0).getString("url")
        response.close()
        urlResult
    }
}
