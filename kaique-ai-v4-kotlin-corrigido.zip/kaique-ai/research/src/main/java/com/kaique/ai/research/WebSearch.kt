package com.kaique.ai.research

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

class WebSearch(private val apiKey: String) {

    suspend fun search(query: String, maxResults: Int = 5): List<SearchResult> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://openrouter.ai/api/v1/search?q=$encoded&max=$maxResults"
        val connection = URL(url).openConnection() as java.net.HttpURLConnection
        connection.setRequestProperty("Authorization", "Bearer $apiKey")
        connection.connectTimeout = 15000
        connection.readTimeout = 15000
        val text = connection.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONObject(text).getJSONArray("results")
        val results = mutableListOf<SearchResult>()
        for (i in 0 until minOf(arr.length(), maxResults)) {
            val obj = arr.getJSONObject(i)
            results.add(SearchResult(
                title = obj.optString("title", "Resultado"),
                url = obj.optString("url", ""),
                summary = obj.optString("snippet", "")
            ))
        }
        results
    }

    data class SearchResult(val title: String, val url: String, val summary: String)
}
