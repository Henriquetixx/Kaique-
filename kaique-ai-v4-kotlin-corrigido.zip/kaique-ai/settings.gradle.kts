pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "KaiqueAI"
// Módulos complementares ainda são protótipos e ficam preservados no ZIP,
// mas fora da compilação até suas integrações serem implementadas.
include(":app", ":core", ":ai-provider", ":voice")
