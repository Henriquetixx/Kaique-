package com.kaique.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Leitura de respostas com o mecanismo TTS instalado no Android. */
class VoiceModule(context: Context) {
    private var initialized = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            initialized = status == TextToSpeech.SUCCESS
            if (initialized) tts?.language = Locale.forLanguageTag("pt-BR")
        }
    }

    fun speak(text: String) {
        if (initialized) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kaique-ai-voice")
    }

    fun stopSpeaking() { tts?.stop() }
    fun release() { tts?.shutdown() }
}
